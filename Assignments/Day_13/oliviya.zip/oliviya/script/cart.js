var cartData = JSON.parse(localStorage.getItem("cart"));
console.log(cartData)